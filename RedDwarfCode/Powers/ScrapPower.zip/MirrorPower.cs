﻿using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Entities.Powers;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Runs;
using MegaCrit.Sts2.Core.ValueProps;

namespace RedDwarf.Code.Powers;


public sealed class MirrorPower : RedDwarfPower
{
    public override PowerType Type => PowerType.Buff;

    public override PowerStackType StackType => PowerStackType.Counter;

    public decimal DamageIncoming = 0;
    public Creature? DamageTarget;
    public PlayerChoiceContext? PlayerChoiceContext;

    public override decimal ModifyHpLostAfterOstyLate(Creature target, decimal amount, ValueProp props, Creature? dealer, CardModel? cardSource)
    {
        if (target != base.Owner)
        {
          
            return amount;
        }

        DamageTarget = dealer;

        DamageIncoming = amount;
    

        return 0m;
    }

    public override async Task AfterModifyingHpLostAfterOsty()
    {
        await PowerCmd.Decrement(this);

        Flash();

        if (PlayerChoiceContext != null && DamageTarget != null)
        {

            await CreatureCmd.Damage(PlayerChoiceContext, DamageTarget, DamageIncoming, ValueProp.Unpowered | ValueProp.SkipHurtAnim, null, null);

        }
    }

    public override async Task BeforeDamageReceived(PlayerChoiceContext choiceContext, Creature target, decimal amount, ValueProp props, Creature? dealer, CardModel? cardSource)
    {
        if (target == base.Owner && dealer != null)
        {
            PlayerChoiceContext = choiceContext;
        }
    }
}
